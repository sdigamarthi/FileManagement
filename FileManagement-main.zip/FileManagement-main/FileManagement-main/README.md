# FileManagement

The project implements the following functionalities -

Code to display the welcome screen. It should display:

Application name and the developer details

The MainMenu will have the options for User to select according to his need 

The first option list the file names in ascending order

The second option returns the details of all the available File Operations like Add a file, Search for a file , Delete a file and Exit.

Display the result upon successful operation

Display the result upon unsuccessful operation

Option to navigate back to the main context

There should be a third option to close the application
